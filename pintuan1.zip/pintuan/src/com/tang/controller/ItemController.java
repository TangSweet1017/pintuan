package com.tang.controller;

import com.tang.base.BaseController;
import com.tang.po.*;
import com.tang.service.*;
import com.tang.utils.Consts;
import com.tang.utils.Pager;
import com.tang.utils.SystemContext;
import com.tang.utils.UUIDUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/item")
public class ItemController extends BaseController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private ItemCategoryService itemCategoryService;

    @Autowired
    private ItemOrderService itemOrderService;
    @Autowired
    private UserService userService;
    @Autowired
    private ItemChildService itemChildService;

    /**
     * 分页查询活动列表
     */
//    @RequestMapping("/findBySql")
//    public String findBySql(Model model, Item item){
//        String sql = "select * from item where isDelete = 0 ";
//        if(!isEmpty(item.getName())){
//            sql += " and name like '%" + item.getName() + "%' ";
//        }
//        sql += " order by id desc";
//        Pager<Item> pagers = itemService.findBySqlRerturnEntity(sql);
//        model.addAttribute("pagers",pagers);
//        model.addAttribute("obj",item);
//        return "item/item";
//    }
    @RequestMapping("/findBySql")
    public String findBySql(String pam2,Model model, Item item,HttpServletRequest request){
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        Integer userId = Integer.valueOf(attribute.toString());
        String sql = "select * from item where isDelete = 0 ";
        sql += " and pam2 like " + pam2;
        sql += " order by id desc";
        Pager<Item> pagers = itemService.findBySqlRerturnEntity(sql);
        model.addAttribute("pagers",pagers);
        model.addAttribute("obj",item);
        model.addAttribute("obj1",userId);
        return "item/item";
    }
    /**
     * 分页查询活动列表
     */
//    @RequestMapping("/findBySql1")
//    public String findBySql1(Model model, Item item,ItemOrder itemOrder){
//        String sql = "select * from item where isDelete = 0 ";
//        if(!isEmpty(item.getPam1())){
//            sql += " and pam1 like '%" + item.getPam1() + "%' ";
//        }
//        sql += " order by id desc";
//        Pager<Item> pagers = itemService.findBySqlRerturnEntity(sql);
//        model.addAttribute("pagers",pagers);
//        model.addAttribute("obj",item);
//        return "item/item1";
//    }
    /**
     * 团长开始活动
     */
    @RequestMapping("/start")
    public String start(Integer id,Model model,HttpServletRequest request){
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        String pam2 = attribute.toString();
        Item obj = itemService.load(id);
        obj.setStatus(1);
        itemService.updateById(obj);
        model.addAttribute("obj",obj);
        return "redirect:/item/findBySql?pam2="+pam2;
    }
    /**
     * 团长开始活动
     */
    @RequestMapping("/end")
    public String end(Integer id,Model model,HttpServletRequest request){
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        String pam2 = attribute.toString();
        Item obj = itemService.load(id);
        obj.setStatus(2);
        itemService.updateById(obj);
        model.addAttribute("obj",obj);
        return "redirect:/item/findBySql?pam2="+pam2;
    }

    /**
     * 添加活动入口
     */
    @RequestMapping("/add")
    public String add(Model model){
        String sql = "select * from item_category where isDelete = 0 and pid is not null order by id";
        List<ItemCategory> listBySqlReturnEntity = itemCategoryService.listBySqlReturnEntity(sql);
        model.addAttribute("types",listBySqlReturnEntity);
        return "item/add";
    }
    @RequestMapping("/useradd")
    public String useradd(Model model,HttpServletRequest request){
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        if(attribute == null){
            return "redirect:/login/uLogin";
        }
        Integer userId = Integer.valueOf(attribute.toString());
        User load = userService.load(userId);
        request.setAttribute("obj",load);
        String sql = "select * from item_category where isDelete = 0 and pid is not null order by id";
        List<ItemCategory> listBySqlReturnEntity = itemCategoryService.listBySqlReturnEntity(sql);
        model.addAttribute("types",listBySqlReturnEntity);
        return "item/useradd";
    }
    /**
     * 执行添加活动
     */
    @RequestMapping("/exAdd")
    public String exAdd(Item item,ItemChild itemChild,@RequestParam("file")CommonsMultipartFile[] files, HttpServletRequest request) throws IOException {
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        String pam2 = attribute.toString();
        itemCommon(item, files, request);
        item.setGmNum(1);
        item.setIsDelete(0);
        item.setScNum(0);
        item.setStatus(0);
        itemService.insert(item);
//        for (ItemChild i:itemChild
//        ) {
//            itemChildService.insert(i);
//
//        }
        int count = 0;
        for (String content:itemChild.getContent().split(",")
             ) {
            ItemChild itemChild1 = new ItemChild();
            itemChild1.setContent(content);
            String[] prizes = itemChild.getZprize().split(",");
            itemChild1.setZprize(prizes[count]);
            itemChild1.setItemId(item.getId());
            itemChildService.insert(itemChild1);
            count++;
        }
        return "redirect:/item/findBySql.action?pam2="+pam2;
    }

    /**
     * 修改活动入口
     */
    @RequestMapping("/update")
    public String update(Integer id,Model model){
        Item obj = itemService.load(id);
        String sql = "select * from item_category where isDelete = 0 and pid is not null order by id";
        List<ItemCategory> listBySqlReturnEntity = itemCategoryService.listBySqlReturnEntity(sql);
        model.addAttribute("types",listBySqlReturnEntity);
        model.addAttribute("obj",obj);
        return "item/update";
    }

    /**
     * 执行修改活动
     */
    @RequestMapping("/exUpdate")
    public String exUpdate(Item item, @RequestParam("file")CommonsMultipartFile[] files, HttpServletRequest request) throws IOException {
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        String pam2 = attribute.toString();
        itemCommon(item, files, request);
        itemService.updateById(item);
        return "redirect:/item/findBySql.action?pam2="+pam2;
    }

    /**
     * 新增和更新的公共方法
     */
    private void itemCommon(Item item, @RequestParam("file") CommonsMultipartFile[] files, HttpServletRequest request) throws IOException {
        if(files.length>0) {
            for (int s = 0; s < files.length; s++) {
                String n = UUIDUtils.create();
                String path = SystemContext.getRealPath() + "\\resource\\ueditor\\upload\\" + n + files[s].getOriginalFilename();
                File newFile = new File(path);
                //通过CommonsMultipartFile的方法直接写文件
                files[s].transferTo(newFile);
                if (s == 0) {
                    item.setUrl1(request.getContextPath()+"\\resource\\ueditor\\upload\\" + n + files[s].getOriginalFilename());
                }
                if (s == 1) {
                    item.setUrl2(request.getContextPath()+"\\resource\\ueditor\\upload\\" + n + files[s].getOriginalFilename());
                }
                if (s == 2) {
                    item.setUrl3(request.getContextPath()+"\\resource\\ueditor\\upload\\" + n + files[s].getOriginalFilename());
                }
                if (s == 3) {
                    item.setUrl4(request.getContextPath()+"\\resource\\ueditor\\upload\\" + n + files[s].getOriginalFilename());
                }
                if (s == 4) {
                    item.setUrl5(request.getContextPath()+"\\resource\\ueditor\\upload\\" + n + files[s].getOriginalFilename());
                }
            }
        }
        ItemCategory byId = itemCategoryService.getById(item.getCategoryIdTwo());
        item.setCategoryIdOne(byId.getPid());
    }

    /**
     * 活动下架
     */
    @RequestMapping("/delete")
    public String update(Integer id,HttpServletRequest request){
        Object attribute = request.getSession().getAttribute(Consts.USERID);
        String pam2 = attribute.toString();
        Item obj = itemService.load(id);
        obj.setIsDelete(1);
        itemService.updateById(obj);
        return "redirect:/item/findBySql.action?pam2="+pam2;
    }
    /**
     * 按关键字或者二级分类查询
     */
    @RequestMapping("/shoplist")
    public String shoplist(Item item,String condition,Model model){
        String sql = "select * from item where isDelete=0";
        if(!isEmpty(item.getCategoryIdTwo())){
            sql +=" and category_id_two = " +item.getCategoryIdTwo();
        }
        if(!isEmpty(condition)){
            sql += " and name like '%" + condition +"%' ";
            model.addAttribute("condition",condition);
        }
        if(!isEmpty(item.getPrice())){
            sql += " order by (price+0) desc";
        }
        if(!isEmpty(item.getGmNum())){
            sql += " order by gmNum desc";
        }
        if(isEmpty(item.getPrice())&&isEmpty(item.getGmNum())){
            sql += " order by id desc";
        }

        Pager<Item> pagers = itemService.findBySqlRerturnEntity(sql);
        model.addAttribute("pagers",pagers);
        model.addAttribute("obj",item);
        return "item/shoplist";
    }
    @RequestMapping("/view")
    public String view(Integer id,Model model1,ItemOrder itemOrder,Model model2){
        Item obj = itemService.load(id);
        String sql = "select * from item_order where item_id = "+id +" and status != 1";
        Pager<ItemOrder> pagers =itemOrderService.findBySqlRerturnEntity(sql);
        model1.addAttribute("obj",obj);
        model2.addAttribute("pagers",pagers);
        model2.addAttribute("obj1",itemOrder);
        return "item/view";
    }
}
