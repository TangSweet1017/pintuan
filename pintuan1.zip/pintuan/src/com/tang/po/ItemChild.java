package com.tang.po;

import java.io.Serializable;

public class ItemChild implements Serializable {

    private Integer id;

    private Integer userId;

    private User user;

    private Item item;

    private Integer itemId;
    private String zprize;

    /**
     * 内容
     */
    private String content;

    public String getZprize() {
        return zprize;
    }

    public void setZprize(String zprize) {
        this.zprize = zprize;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ItemChild() {
    }

    public ItemChild(Integer id, Integer userId, Integer itemId, String content,String zprize) {
        this.id = id;
        this.userId = userId;
        this.itemId = itemId;
        this.content = content;
        this.zprize =zprize;
    }
}