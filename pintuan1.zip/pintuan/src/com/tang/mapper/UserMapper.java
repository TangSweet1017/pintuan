package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.User;

public interface UserMapper extends BaseDao<User> {
}
