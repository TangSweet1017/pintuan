package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.News;

public interface NewsMapper extends BaseDao<News> {
}
