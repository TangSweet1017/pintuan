package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.OrderDetail;

public interface OrderDetailMapper extends BaseDao<OrderDetail> {
}
