package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.Manage;

/**
 * 管理员
 */
public interface ManageMapper extends BaseDao<Manage> {
}
