package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.ItemChild;

public interface ItemChildMapper extends BaseDao<ItemChild>{

}
