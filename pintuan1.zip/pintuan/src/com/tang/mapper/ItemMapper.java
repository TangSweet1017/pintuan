package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.Item;

public interface
ItemMapper extends BaseDao<Item> {
}