package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.ItemCategory;

public interface ItemCategoryMapper extends BaseDao<ItemCategory> {
}
