package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.ItemOrder;

public interface ItemOrderMapper extends BaseDao<ItemOrder> {
}
