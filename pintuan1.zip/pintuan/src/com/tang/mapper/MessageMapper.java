package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.Message;

/**
 * 留言
 */
public interface MessageMapper extends BaseDao<Message> {
}
