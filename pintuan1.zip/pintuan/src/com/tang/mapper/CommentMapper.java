package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.Comment;

public interface CommentMapper extends BaseDao<Comment> {
}
