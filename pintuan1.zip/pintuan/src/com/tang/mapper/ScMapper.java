package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.Sc;

public interface ScMapper extends BaseDao<Sc> {
}
