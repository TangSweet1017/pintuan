package com.tang.mapper;

import com.tang.base.BaseDao;
import com.tang.po.Car;

public interface CarMapper extends BaseDao<Car> {
}
