package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.News;

public interface NewsService extends BaseService<News> {
}
