package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.OrderDetail;

public interface OrderDetailService extends BaseService<OrderDetail> {
}
