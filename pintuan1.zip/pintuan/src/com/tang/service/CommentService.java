package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.Comment;

public interface CommentService extends BaseService<Comment> {
}
