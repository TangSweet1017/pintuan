package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.ItemCategory;

public interface ItemCategoryService extends BaseService<ItemCategory> {
}
