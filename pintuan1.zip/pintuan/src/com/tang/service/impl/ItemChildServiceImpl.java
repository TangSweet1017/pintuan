package com.tang.service.impl;

import com.tang.base.BaseDao;
import com.tang.base.BaseServiceImpl;
import com.tang.mapper.ItemChildMapper;
import com.tang.po.ItemChild;
import com.tang.service.ItemChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ItemChildServiceImpl extends BaseServiceImpl<ItemChild> implements ItemChildService {

    @Autowired
    private ItemChildMapper itemChildMapper;

    @Override
    public BaseDao<ItemChild> getBaseDao() {
        return itemChildMapper;
    }
}