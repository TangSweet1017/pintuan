package com.tang.service.impl;

import com.tang.base.BaseDao;
import com.tang.base.BaseServiceImpl;
import com.tang.mapper.ItemCategoryMapper;
import com.tang.po.ItemCategory;
import com.tang.service.ItemCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ItemCategoryServiceImpl extends BaseServiceImpl<ItemCategory> implements ItemCategoryService {
    @Autowired
    ItemCategoryMapper itemCategoryMapper;

    @Override
    public BaseDao<ItemCategory> getBaseDao() {
        return itemCategoryMapper;
    }
}
