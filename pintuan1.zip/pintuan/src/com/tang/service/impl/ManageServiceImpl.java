package com.tang.service.impl;

import com.tang.base.BaseDao;
import com.tang.base.BaseServiceImpl;
import com.tang.mapper.ManageMapper;
import com.tang.po.Manage;
import com.tang.service.ManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManageServiceImpl extends BaseServiceImpl<Manage> implements ManageService {
    @Autowired
    ManageMapper manageMapper;

    @Override
    public BaseDao<Manage> getBaseDao() {
        return manageMapper;
    }
}
