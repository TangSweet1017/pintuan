package com.tang.service.impl;

import com.tang.base.BaseDao;
import com.tang.base.BaseServiceImpl;
import com.tang.mapper.ItemMapper;
import com.tang.po.Item;
import com.tang.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ItemServiceImpl extends BaseServiceImpl<Item> implements ItemService {

    @Autowired
    private ItemMapper itemMapper;
    @Override
    public BaseDao<Item> getBaseDao() {
        return itemMapper;
    }
}
