package com.tang.service.impl;

import com.tang.base.BaseDao;
import com.tang.base.BaseServiceImpl;
import com.tang.mapper.NewsMapper;
import com.tang.po.News;
import com.tang.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NewsServiceImpl extends BaseServiceImpl<News> implements NewsService {

    @Autowired
    private NewsMapper newsMapper;

    @Override
    public BaseDao<News> getBaseDao() {
        return newsMapper;
    }
}
