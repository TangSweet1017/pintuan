package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.Car;

public interface CarService extends BaseService<Car> {
}
