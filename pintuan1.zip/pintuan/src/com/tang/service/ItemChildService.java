package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.ItemChild;

public interface ItemChildService extends BaseService<ItemChild> {
}
