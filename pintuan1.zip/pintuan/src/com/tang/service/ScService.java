package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.Sc;

public interface ScService extends BaseService<Sc> {
}
