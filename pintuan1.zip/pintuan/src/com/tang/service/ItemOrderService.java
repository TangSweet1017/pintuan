package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.ItemOrder;

public interface ItemOrderService extends BaseService<ItemOrder> {
}
