package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.Message;

public interface MessageService extends BaseService<Message> {
}
