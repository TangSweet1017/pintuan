package com.tang.service;

import com.tang.base.BaseService;
import com.tang.po.User;

public interface UserService extends BaseService<User> {
}
